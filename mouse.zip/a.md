# Home
1. Buy 页面实现 1天
2. NFT 价格获取 价格计算 以及Buy 功能 1天
3. connect wallet 2 种钱包 以及链接钱包后的状态 1天
