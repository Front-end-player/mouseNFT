$(function(){
    alert("Hello JS");
});
$